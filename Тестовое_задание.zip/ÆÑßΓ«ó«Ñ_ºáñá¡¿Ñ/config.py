# Список городов, для которых нужно собирать данные
CITIES = ['Tokyo', 'Delhi', 'Shanghai', 'São Paulo',
                         'Mexico City', 'Cairo', 'Mumbai', 'Beijing',
                         'Dhaka', 'Osaka', 'New York', 'Karachi',
                         'Buenos Aires', 'Chongqing', 'Istanbul',
                         'Kolkata', 'Manila', 'Lagos', 'Rio de Janeiro',
                         'Tianjin', 'Kinshasa', 'Guangzhou', 'Los Angeles',
                         'Moscow', 'Shenzhen', 'Lahore', 'Bangalore', 'Paris',
                         'Bogotá', 'Jakarta', 'Chennai', 'Lima', 'Bangkok',
                         'Seoul', 'Nagoya', 'Hyderabad', 'London', 'Tehran',
                         'Chicago', 'Chengdu', 'Nanjing', 'Wuhan',
                         'Ho Chi Minh City', 'Luanda', 'Ahmedabad',
                         'Kuala Lumpur', 'Hong Kong', 'Dongguan', 'Foshan',
                         'Hangzhou']
